
Changes to sdcc to allow compilation using the z88dk libraries.


* sdcc-externs.patch

svn patch applied to the current sdcc checked out from svn.

After applying the patch you must rebuild sdcc.


* sdcc.exe

windows executable with patch already applied.

Replace your current sdcc executable with this.

This patch is proposed for application to the sdcc codebase.  Currently regression tests for
stm8 and hc08 processors are failing with the patch applied.
