The sdcc patch is now found in z88dk/src/zsdcc
