
Changes to sdcc to allow compilation using the z88dk libraries.
http://www.z88dk.org/wiki/doku.php?id=temp:front#sdcc1

"sdcc_peeph.3" should be copied to z88dk/libsrc/_DEVELOPMENT, overwriting the file there now.
These are updated rules for sdcc's peephole optimizer.  If you suspect the peephole rules are
faulty try compiling at lower optimization level (-SO2) to see if problems go away.
