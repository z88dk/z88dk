The sdcc patch is now found in z88dk/src/zsdcc
https://github.com/z88dk/z88dk/tree/master/src/zsdcc
