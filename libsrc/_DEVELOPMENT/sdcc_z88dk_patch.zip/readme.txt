
Changes to sdcc to allow compilation using the z88dk libraries.
http://www.z88dk.org/wiki/doku.php?id=temp:front#sdcc1

The following files should be copied to z88dk/libsrc/_DEVELOPMENT, overwriting the
files of the same name there now:

"sdcc_peeph.1"
Intrinsics were added to the library.

"sdcc_peeph.2"
Intrinsics were added to the library.
A code generation error was discovered in sdcc and a rule was added to fix it.

"sdcc_peeph.3"
Intrinsics were added to the library.
A code generation error was discovered in sdcc and a rule was added to fix it.
These are updated rules for sdcc's peephole optimizer that are activated when -SO3 appears
on the compile line.  If you suspect the peephole rules are faulty try compiling again at
lower optimization level (-SO2) to see if problems go away.

"sdcc_peeph_cs.1"
New since the release, this rule set augments the non-cs version with rules to
reduce code size.

"sdcc_peeph_cs.2"
New since the release, this rule set augments the non-cs version with rules to
reduce code size.

"sdcc_peeph_cs.3"
New since the release, this rule set augments the non-cs version with rules to
reduce code size.

"sdcc_opt.1"
These are rules that translate sdcc's asz80 syntax to regular zilog syntax.  They have
been updated since the last release.

"sdcc_opt.2"
These are rules that change sdcc's calls to its primitives to callee linkage.  They have
been updated since the last release.
