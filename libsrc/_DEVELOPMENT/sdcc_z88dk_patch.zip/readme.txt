
Changes to sdcc to allow compilation using the z88dk libraries.
http://www.z88dk.org/wiki/doku.php?id=temp:front#sdcc
