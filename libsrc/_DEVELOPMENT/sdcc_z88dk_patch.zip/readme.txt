
Changes to sdcc to allow compilation using the z88dk libraries.
http://www.z88dk.org/wiki/doku.php?id=temp:front#sdcc1

"sdcc_peeph.2" should be copied to z88dk/libsrc/_DEVELOPMENT, overwriting the file there now.
A code generation error was discovered in sdcc and a rule was added to fix it.

"sdcc_peeph.3" should be copied to z88dk/libsrc/_DEVELOPMENT, overwriting the file there now.
These are updated rules for sdcc's peephole optimizer that are activated when -SO3 appears
on the compile line.  If you suspect the peephole rules are faulty try compiling again at
lower optimization level (-SO2) to see if problems go away.

"sdcc_opt.1" should be copied to z88dk/libsrc/_DEVELOPMENT, overwriting the file there now.
These are rules that translate sdcc's asz80 syntax to regular zilog syntax.  They have
been updated since the last release.
