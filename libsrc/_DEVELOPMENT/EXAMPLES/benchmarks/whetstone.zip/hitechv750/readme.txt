
HITECH-C Z80 v7.50 FOR MSDOS

Using the IDE HPDZ.EXE select maximum optimization in compiles.

1. Verify correct output

Enable float in printf
Compile for CP/M target and run on cpm emulator.
(produces incorrect results at all optimization levels)

2. Create minimal binary for comparison

* Add "#define NOPRINTF", "#define NOCOMMAND" to source code
* Disable float in printf
* Compile with selections: ROM code, binary image and full optimization.

size (from ide dialog): 6627 + 245 = 6872 (exclude User and first ROM section which correspond to startup code)

ticks_start = 0x10c, ticks_end = 0x9a3 from whetdc.sym
ticks whetdc.bin -start 10c -end 9a3 -counter 99999999999
time: 549,948,026 (invalid, incorrect results)
