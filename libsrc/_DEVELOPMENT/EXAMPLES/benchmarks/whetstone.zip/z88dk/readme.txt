
Z88DK COMPILES

* sccz80 Classic :- sccz80 compiler using classic c library
* sccz80 New     :- sccz80 compiler using new c library
* sdcc   New     :- sdcc compiler using new c library

//////////////
SCCZ80 CLASSIC
//////////////

1. Verify correct output

zcc +cpm -vn -DNOTIMER whetstone-cla.c -o whetdc -lm
Run output on cpm emulator.

2. Create minimal binary for comparison

zcc +test -vn -DNOTIMER -DNOCOMMAND -DNOPRINTF whetstone-cla.c -o whetdc -lm -m
size: 5513 - 149 = 5364 bytes with startup code removed
ticks_start = 0xf7, ticks_end = 0xa1f from whetdc.map
ticks sieve -start f7 -end a1f -counter 99999999999
time: 1,295,331,166

//////////
SCCZ80 NEW
//////////

(libraries must be built to enable printf converters %ld %d %e %f)

1. Verify correct output

zcc +cpm -vn -DNOTIMER -clib=new whetstone.c -o whetdc -lm
Run output on cpm emulator.

2. Create minimal binary for comparison

zcc +embedded -vn -startup=0 -clib=new whetstone.c -o whetdc -lm -m -DNOTIMER -DNOCOMMAND -DNOPRINTF
size: 5411 - 111 = 5300 bytes with startup code removed
ticks_start = 0x8c3, ticks_end = 0x11ac from whetdc.map
ticks whetdc_CODE.bin -start 8c3 -end 11ac -counter 99999999999
time: 974,224,224

////////
SDCC NEW
////////

(libraries must be built to enable printf converters %ld %d %e %f)

1. Verify correct output

zcc +cpm -vn -DNOTIMER -clib=sdcc_iy --max-allocs-per-node200000 whetstone.c -o whetdc -lm
Run output on cpm emulator.

2. Create minimal binary for comparison

zcc +embedded -vn -startup=0 -clib=sdcc_iy --max-allocs-per-node200000 whetstone.c -o whetdc -lm -m -DNOTIMER -DNOCOMMAND -DNOPRINTF
size: 6666 - 111 = 6555 bytes without startup code
ticks_start = 0x82d, ticks_end = 0x14b4 from whetdc.map
ticks whetdc_CODE.bin -start 82d -end 14b4 -counter 99999999999
time: 924,652,466
